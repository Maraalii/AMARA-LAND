# Intro to Amara

A Pen created on CodePen.

Original URL: [https://codepen.io/Princesss-School/pen/MYYwLeZ](https://codepen.io/Princesss-School/pen/MYYwLeZ).

